# Put your 100 celebrity images here.
# Supported formats: .jpg, .png, .jpeg, .webp
