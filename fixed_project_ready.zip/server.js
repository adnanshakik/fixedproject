import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import fs from "fs/promises";
import { fileURLToPath } from "url";
import multer from "multer";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const RATINGS_FILE = path.join(__dirname, "ratings.json");
const IMAGES_DIR = path.join(__dirname, "public", "images");

// Configure multer for storage
const storage = multer.diskStorage({
  destination: async (req, file, cb) => {
    await fs.mkdir(IMAGES_DIR, { recursive: true });
    cb(null, IMAGES_DIR);
  },
  filename: (req, file, cb) => {
    // Keep original filename but sanitize it slightly
    const sanitized = file.originalname.replace(/[^a-zA-Z0-9.-]/g, "_");
    cb(null, sanitized);
  }
});

const upload = multer({ 
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|webp|gif/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    if (extname && mimetype) {
      return cb(null, true);
    }
    cb(new Error("Only images are allowed (jpeg, jpg, png, webp, gif)"));
  }
});

async function startServer() {
  const app = express();
  const PORT = process.env.PORT || 3000;

  app.use(express.json());
  app.use("/images", express.static(IMAGES_DIR));

  // Ensure directories and files exist
  try {
    await fs.mkdir(IMAGES_DIR, { recursive: true });
    await fs.access(RATINGS_FILE);
  } catch {
    await fs.writeFile(RATINGS_FILE, JSON.stringify([])); // Array of { userId, imageId, rating }
  }

  // API Routes
  app.post("/api/upload", upload.array("photos", 100), (req, res) => {
    res.json({ success: true, count: req.files?.length || 0 });
  });

  app.delete("/api/delete-image/:filename", async (req, res) => {
    const { filename } = req.params;
    try {
      const filePath = path.join(IMAGES_DIR, filename);
      await fs.unlink(filePath);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete image" });
    }
  });

  app.post("/api/clear-images", async (req, res) => {
    try {
      const files = await fs.readdir(IMAGES_DIR);
      for (const file of files) {
        if (file !== "README.md") {
          await fs.unlink(path.join(IMAGES_DIR, file));
        }
      }
      // Also clear ratings
      await fs.writeFile(RATINGS_FILE, JSON.stringify([]));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to clear images" });
    }
  });

  app.get("/api/images", async (req, res) => {
    try {
      const files = await fs.readdir(IMAGES_DIR);
      const imageExtensions = [".jpg", ".jpeg", ".png", ".webp", ".gif"];
      const imageFiles = files.filter(file => 
        imageExtensions.includes(path.extname(file).toLowerCase())
      );

      if (imageFiles.length === 0) {
        // Fallback for demo if no images uploaded yet
        const demoImages = Array.from({ length: 100 }, (_, i) => ({
          id: i + 1,
          url: `https://picsum.photos/seed/celeb${i + 1}/800/1000`,
          name: `Celebrity ${i + 1} (Demo)`
        }));
        return res.json(demoImages);
      }

      const images = imageFiles.map((file, i) => ({
        id: i + 1,
        url: `/images/${file}`,
        name: path.parse(file).name.replace(/[-_]/g, " ")
      }));
      res.json(images);
    } catch (error) {
      res.status(500).json({ error: "Failed to read images directory" });
    }
  });

  app.post("/api/rate", async (req, res) => {
    const { userId, imageId, rating } = req.body;
    if (!userId || typeof imageId !== "number" || typeof rating !== "number") {
      return res.status(400).json({ error: "Invalid data" });
    }

    try {
      const ratings = JSON.parse(await fs.readFile(RATINGS_FILE, "utf-8"));
      
      // Update existing rating if user already rated this image, otherwise add new
      const existingIndex = ratings.findIndex((r: any) => r.userId === userId && r.imageId === imageId);
      if (existingIndex > -1) {
        ratings[existingIndex].rating = rating;
      } else {
        ratings.push({ userId, imageId, rating, timestamp: new Date().toISOString() });
      }

      await fs.writeFile(RATINGS_FILE, JSON.stringify(ratings, null, 2));
      
      // Calculate average for this image
      const imageRatings = ratings.filter((r: any) => r.imageId === imageId);
      const average = imageRatings.reduce((acc: number, r: any) => acc + r.rating, 0) / imageRatings.length;
      
      res.json({ success: true, average });
    } catch (error) {
      res.status(500).json({ error: "Failed to save rating" });
    }
  });

  app.get("/api/stats", async (req, res) => {
    try {
      const ratings = JSON.parse(await fs.readFile(RATINGS_FILE, "utf-8"));
      res.json(ratings);
    } catch (error) {
      res.status(500).json({ error: "Failed to load stats" });
    }
  });

  app.get("/api/user-progress/:userId", async (req, res) => {
    const { userId } = req.params;
    try {
      const ratings = JSON.parse(await fs.readFile(RATINGS_FILE, "utf-8"));
      const userRatings = ratings.filter((r: any) => r.userId === userId);
      res.json({ count: userRatings.length, ratedIds: userRatings.map((r: any) => r.imageId) });
    } catch (error) {
      res.status(500).json({ error: "Failed to load progress" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
