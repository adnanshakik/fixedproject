/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Star, ChevronRight, CheckCircle, Users, Image as ImageIcon, BarChart3, Upload, Trash2, X, AlertCircle } from "lucide-react";

interface CelebrityImage {
  id: number;
  url: string;
  name: string;
}

interface RatingStats {
  [key: number]: {
    total: number;
    count: number;
  };
}

const TEAM_MEMBERS = [
  "Md. Adnan Shafiq (252-25-982)",
  "Md. Shajidur Rahman (252-15-991)",
  "Md. Ruhul Amin (252-15-415)",
  "Ridwan Ahmed (252-15-965)",
  "Rifat Karim (252-15-647)"
];

export default function App() {
  const [view, setView] = useState<"mentor" | "team" | "login" | "rating" | "completion" | "admin">("mentor");
  const [userId, setUserId] = useState<string>("");
  const [loginId, setLoginId] = useState<string>("");
  const [images, setImages] = useState<CelebrityImage[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [currentRating, setCurrentRating] = useState<number | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [stats, setStats] = useState<any[]>([]);
  const [uploadStatus, setUploadStatus] = useState<{ type: 'success' | 'error', message: string } | null>(null);
  const [loginError, setLoginError] = useState<string | null>(null);
  const [adminPassword, setAdminPassword] = useState<string>("");
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    // Check for existing session
    const savedId = localStorage.getItem("celebRate_userId");
    if (savedId) {
      setUserId(savedId);
    }
    const savedAdmin = localStorage.getItem("celebRate_adminAuth");
    if (savedAdmin === "true") {
      setIsAdminAuthenticated(true);
    }
  }, []);

  useEffect(() => {
    if ((view === "rating" || view === "admin") && images.length === 0) {
      fetchImages();
    }
    if (view === "rating" && userId) {
      fetchUserProgress();
    }
  }, [view, userId]);

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminPassword === "1234567890") {
      setIsAdminAuthenticated(true);
      localStorage.setItem("celebRate_adminAuth", "true");
      setAdminPassword("");
    } else {
      alert("Incorrect admin password!");
    }
  };

  const handleAdminLogout = () => {
    setIsAdminAuthenticated(false);
    localStorage.removeItem("celebRate_adminAuth");
    setView("team");
  };

  const fetchImages = async () => {
    setIsLoading(true);
    try {
      const response = await fetch("/api/images");
      const data = await response.json();
      setImages(data);
    } catch (error) {
      console.error("Failed to fetch images:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchUserProgress = async () => {
    try {
      const response = await fetch(`/api/user-progress/${userId}`);
      const data = await response.json();
      // Find the first unrated image index
      const firstUnrated = images.findIndex(img => !data.ratedIds.includes(img.id));
      if (firstUnrated !== -1) {
        setCurrentIndex(firstUnrated);
      } else if (data.count === images.length && images.length > 0) {
        setView("completion");
      }
    } catch (error) {
      console.error("Failed to fetch user progress:", error);
    }
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const idPattern = /^252-15-\d{3}$/;
    if (idPattern.test(loginId)) {
      setUserId(loginId);
      localStorage.setItem("celebRate_userId", loginId);
      setView("rating");
      setLoginError(null);
    } else {
      setLoginError("Invalid ID format. Use 252-15-XXX (e.g., 252-15-982)");
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("celebRate_userId");
    setUserId("");
    setView("team");
  };

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsLoading(true);
    setUploadStatus(null);
    const formData = new FormData();
    for (let i = 0; i < files.length; i++) {
      formData.append("photos", files[i]);
    }

    try {
      const response = await fetch("/api/upload", {
        method: "POST",
        body: formData
      });
      const data = await response.json();
      if (data.success) {
        setUploadStatus({ type: 'success', message: `Successfully uploaded ${data.count} photos!` });
        fetchImages();
      } else {
        setUploadStatus({ type: 'error', message: data.error || "Upload failed" });
      }
    } catch (error) {
      setUploadStatus({ type: 'error', message: "Network error during upload" });
    } finally {
      setIsLoading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  const deleteImage = async (id: number, url: string) => {
    if (!confirm("Are you sure you want to delete this image?")) return;
    
    const filename = url.split("/").pop();
    try {
      const response = await fetch(`/api/delete-image/${filename}`, { method: "DELETE" });
      if (response.ok) {
        fetchImages();
      }
    } catch (error) {
      console.error("Failed to delete image:", error);
    }
  };

  const clearImages = async () => {
    if (!confirm("Are you sure you want to delete all uploaded images and reset ratings?")) return;
    
    setIsLoading(true);
    try {
      await fetch("/api/clear-images", { method: "POST" });
      setImages([]);
      setUploadStatus({ type: 'success', message: "All images cleared" });
    } catch (error) {
      setUploadStatus({ type: 'error', message: "Failed to clear images" });
    } finally {
      setIsLoading(false);
    }
  };

  const handleRate = async (rating: number) => {
    setCurrentRating(rating);
  };

  const handleNext = async () => {
    if (currentRating === null) return;

    const imageId = images[currentIndex].id;
    try {
      await fetch("/api/rate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId, imageId, rating: currentRating })
      });

      if (currentIndex < images.length - 1) {
        setCurrentIndex(prev => prev + 1);
        setCurrentRating(null);
      } else {
        setIsLoading(true);
        const statsRes = await fetch("/api/stats");
        const statsData = await statsRes.json();
        setStats(statsData);
        setIsLoading(false);
        setView("completion");
      }
    } catch (error) {
      console.error("Failed to save rating:", error);
    }
  };

  const progress = images.length > 0 ? ((currentIndex + 1) / images.length) * 100 : 0;

  if (view === "mentor") {
    return (
      <div className="min-h-screen bg-neutral-950 text-white flex flex-col items-center justify-center p-6 font-sans relative overflow-hidden">
        {/* Decorative elements */}
        <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
          <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-emerald-500/10 rounded-full blur-[120px]" />
          <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-cyan-500/10 rounded-full blur-[120px]" />
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-3xl w-full text-center space-y-16 relative z-10"
        >
          <div className="space-y-6">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.8 }}
              className="inline-block px-6 py-2 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-sm font-bold uppercase tracking-[0.2em] mb-4"
            >
              Academic Excellence
            </motion.div>
            <h1 className="text-7xl font-bold tracking-tighter bg-gradient-to-b from-white to-neutral-500 bg-clip-text text-transparent">Our Mentor</h1>
          </div>

          <div className="space-y-4 py-8">
            <motion.h2 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.3, duration: 0.8 }}
              className="text-5xl md:text-6xl font-bold text-white tracking-tight"
            >
              Professor Md. Akhtaruzzaman
            </motion.h2>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
              className="flex flex-col items-center gap-3"
            >
              <div className="h-px w-24 bg-emerald-500/50" />
              <p className="text-emerald-400 text-xl font-medium tracking-wide">
                Honorable Mentor & Guide
              </p>
              <p className="text-neutral-500 text-lg italic max-w-md">
                Department of Computer Science and Engineering, DIU
              </p>
            </motion.div>
          </div>

          <motion.button
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8 }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setView("team")}
            className="group relative inline-flex items-center gap-3 bg-white text-black px-14 py-5 rounded-full font-bold text-xl transition-all hover:bg-emerald-400 shadow-2xl shadow-emerald-500/20"
          >
            Continue
            <ChevronRight className="transition-transform group-hover:translate-x-1" />
          </motion.button>
        </motion.div>
      </div>
    );
  }

  if (view === "team") {
    return (
      <div className="min-h-screen bg-neutral-950 text-white flex flex-col items-center justify-center p-6 font-sans relative">
        <button 
          onClick={() => setView("admin")}
          className="absolute top-6 right-6 p-3 rounded-full bg-neutral-900 border border-neutral-800 text-neutral-500 hover:text-white transition-colors"
          title="Admin Login"
        >
          <Upload size={20} />
        </button>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-2xl w-full text-center space-y-12"
        >
          <div className="space-y-4">
            <motion.h1 
              className="text-6xl font-bold tracking-tighter bg-gradient-to-r from-emerald-400 to-cyan-400 bg-clip-text text-transparent"
              animate={{ scale: [1, 1.02, 1] }}
              transition={{ duration: 4, repeat: Infinity }}
            >
              CelebRate
            </motion.h1>
            <p className="text-neutral-400 text-lg">The ultimate Bangladeshi celebrity photo rating platform.</p>
          </div>

          <div className="bg-neutral-900/50 border border-neutral-800 rounded-3xl p-10 backdrop-blur-sm shadow-2xl">
            <div className="flex items-center justify-center gap-2 mb-8 text-emerald-400">
              <Users size={24} />
              <h2 className="font-bold uppercase tracking-[0.2em] text-sm">Project Team</h2>
            </div>
            <ul className="space-y-4">
              {TEAM_MEMBERS.map((member, i) => (
                <motion.li 
                  key={member}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.1 }}
                  className="text-neutral-200 font-semibold text-lg flex items-center justify-center gap-3"
                >
                  <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full" />
                  {member}
                </motion.li>
              ))}
            </ul>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setView(userId ? "rating" : "login")}
              className="group relative inline-flex items-center justify-center gap-2 bg-white text-black px-12 py-4 rounded-full font-bold text-xl transition-all hover:bg-emerald-400"
            >
              {userId ? "Continue Experience" : "Enter Experience"}
              <ChevronRight className="transition-transform group-hover:translate-x-1" />
            </motion.button>
          </div>

          <button 
            onClick={() => setView("mentor")}
            className="text-neutral-500 hover:text-white text-sm font-medium transition-colors"
          >
            Back to Mentor
          </button>
        </motion.div>
      </div>
    );
  }

  if (view === "login") {
    return (
      <div className="min-h-screen bg-neutral-950 text-white flex flex-col items-center justify-center p-6 font-sans">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="max-w-md w-full bg-neutral-900 border border-neutral-800 rounded-3xl p-8 space-y-8"
        >
          <div className="text-center space-y-2">
            <h2 className="text-3xl font-bold tracking-tight">Welcome Back</h2>
            <p className="text-neutral-400 text-sm">Please enter your ID to start rating.</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-6">
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-widest text-neutral-500 ml-1">User ID</label>
              <input 
                type="text" 
                placeholder="252-15-XXX"
                value={loginId}
                onChange={(e) => setLoginId(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-2xl px-6 py-4 focus:outline-none focus:border-emerald-500 transition-colors font-mono text-lg"
                autoFocus
              />
              {loginError && (
                <motion.p 
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="text-red-400 text-xs mt-2 ml-1 flex items-center gap-1"
                >
                  <AlertCircle size={14} />
                  {loginError}
                </motion.p>
              )}
            </div>

            <button 
              type="submit"
              className="w-full py-4 bg-white text-black rounded-2xl font-bold text-lg hover:bg-emerald-400 transition-colors"
            >
              Login & Continue
            </button>
          </form>

          <button 
            onClick={() => setView("team")}
            className="w-full text-neutral-500 hover:text-white text-sm font-medium transition-colors"
          >
            Back to Home
          </button>
        </motion.div>
      </div>
    );
  }

  if (view === "admin") {
    if (!isAdminAuthenticated) {
      return (
        <div className="min-h-screen bg-neutral-950 text-white flex flex-col items-center justify-center p-6 font-sans">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="max-w-md w-full bg-neutral-900 border border-neutral-800 rounded-3xl p-8 space-y-8"
          >
            <div className="text-center space-y-2">
              <h2 className="text-3xl font-bold tracking-tight">Admin Login</h2>
              <p className="text-neutral-400 text-sm">Enter password to access admin settings.</p>
            </div>

            <form onSubmit={handleAdminLogin} className="space-y-6">
              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-widest text-neutral-500 ml-1">Password</label>
                <input 
                  type="password" 
                  placeholder="••••••••"
                  value={adminPassword}
                  onChange={(e) => setAdminPassword(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-2xl px-6 py-4 focus:outline-none focus:border-emerald-500 transition-colors font-mono text-lg"
                  autoFocus
                />
              </div>

              <button 
                type="submit"
                className="w-full py-4 bg-white text-black rounded-2xl font-bold text-lg hover:bg-emerald-400 transition-colors"
              >
                Access Admin
              </button>
            </form>

            <button 
              onClick={() => setView("team")}
              className="w-full text-neutral-500 hover:text-white text-sm font-medium transition-colors"
            >
              Back to Home
            </button>
          </motion.div>
        </div>
      );
    }

    return (
      <div className="min-h-screen bg-neutral-950 text-white flex flex-col items-center justify-center p-6 font-sans">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="max-w-2xl w-full bg-neutral-900 border border-neutral-800 rounded-3xl p-8 space-y-8 relative"
        >
          <div className="flex justify-between items-center">
            <div className="space-y-1">
              <h2 className="text-3xl font-bold tracking-tight">Admin Settings</h2>
              <p className="text-neutral-400 text-sm">Manage your celebrity photo collection.</p>
            </div>
            <div className="flex gap-2">
              <button 
                onClick={handleAdminLogout}
                className="p-2 rounded-full hover:bg-red-500/10 text-red-500 transition-colors"
                title="Logout Admin"
              >
                <X size={24} />
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-4">
              <input 
                type="file" 
                multiple 
                accept="image/*"
                onChange={handleUpload}
                ref={fileInputRef}
                className="hidden"
              />
              <button 
                onClick={() => fileInputRef.current?.click()}
                disabled={isLoading}
                className="w-full h-32 border-2 border-dashed border-neutral-800 rounded-2xl flex flex-col items-center justify-center gap-2 hover:border-emerald-500/50 hover:bg-emerald-500/5 transition-all group"
              >
                <Upload className="text-neutral-500 group-hover:text-emerald-400" size={32} />
                <span className="text-sm font-medium text-neutral-400 group-hover:text-white">Upload Photos</span>
              </button>
            </div>

            <button 
              onClick={clearImages}
              disabled={isLoading}
              className="w-full h-32 border-2 border-dashed border-neutral-800 rounded-2xl flex flex-col items-center justify-center gap-2 hover:border-red-500/50 hover:bg-red-500/5 transition-all group"
            >
              <Trash2 className="text-neutral-500 group-hover:text-red-400" size={32} />
              <span className="text-sm font-medium text-neutral-400 group-hover:text-white">Clear All Images</span>
            </button>
          </div>

          <AnimatePresence>
            {uploadStatus && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className={`p-4 rounded-xl flex items-center gap-3 ${
                  uploadStatus.type === 'success' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-red-500/10 text-red-400 border border-red-500/20'
                }`}
              >
                {uploadStatus.type === 'success' ? <CheckCircle size={20} /> : <AlertCircle size={20} />}
                <p className="text-sm font-medium">{uploadStatus.message}</p>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="pt-6 border-t border-neutral-800 space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="font-bold text-lg">Current Library</h3>
              <span className="font-mono text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-full text-sm">{images.length} Photos</span>
            </div>
            
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 max-h-[300px] overflow-y-auto p-2 bg-neutral-950 rounded-2xl border border-neutral-800">
              {images.length === 0 ? (
                <div className="col-span-full py-12 text-center text-neutral-500 text-sm italic">
                  No images uploaded yet.
                </div>
              ) : (
                images.map((img) => (
                  <div key={img.id} className="relative group aspect-[4/5] rounded-xl overflow-hidden bg-neutral-900 border border-neutral-800">
                    <img 
                      src={img.url} 
                      alt={img.name} 
                      className="w-full h-full object-cover transition-transform group-hover:scale-110"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <button 
                        onClick={() => deleteImage(img.id, img.url)}
                        className="p-2 bg-red-500 text-white rounded-full hover:bg-red-600 transition-colors shadow-lg"
                        title="Delete Image"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          <button 
            onClick={() => setView("team")}
            className="w-full py-4 bg-white text-black rounded-2xl font-bold hover:bg-emerald-400 transition-colors"
          >
            Back to Home
          </button>
        </motion.div>
      </div>
    );
  }

  if (view === "rating") {
    const currentImage = images[currentIndex];

    return (
      <div className="min-h-screen bg-neutral-950 text-white flex flex-col font-sans">
        {/* Header */}
        <header className="p-6 border-b border-neutral-800 flex justify-between items-center bg-neutral-950/80 backdrop-blur-md sticky top-0 z-10">
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setView("team")}
              className="p-2 hover:bg-neutral-900 rounded-full transition-colors text-neutral-500 hover:text-white"
            >
              <X size={20} />
            </button>
            <div className="w-10 h-10 bg-emerald-500 rounded-lg flex items-center justify-center font-bold text-black">C</div>
            <h1 className="text-xl font-bold tracking-tight">CelebRate</h1>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right hidden sm:block">
              <p className="text-xs text-neutral-500 uppercase font-bold tracking-wider">User: {userId}</p>
              <button 
                onClick={handleLogout}
                className="text-[10px] text-red-500 hover:text-red-400 uppercase font-bold tracking-widest transition-colors"
              >
                Logout
              </button>
            </div>
            <div className="text-right hidden sm:block">
              <p className="text-xs text-neutral-500 uppercase font-bold tracking-wider">Progress</p>
              <p className="text-sm font-mono">{currentIndex + 1} / {images.length}</p>
            </div>
            <div className="w-32 h-2 bg-neutral-800 rounded-full overflow-hidden">
              <motion.div 
                className="h-full bg-emerald-400"
                initial={{ width: 0 }}
                animate={{ width: `${progress}%` }}
              />
            </div>
          </div>
        </header>

        <main className="flex-1 flex flex-col items-center justify-center p-4 sm:p-8">
          <AnimatePresence mode="wait">
            {isLoading ? (
              <motion.div 
                key="loader"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex flex-col items-center gap-4"
              >
                <div className="w-12 h-12 border-4 border-emerald-500/20 border-t-emerald-500 rounded-full animate-spin" />
                <p className="text-neutral-500 animate-pulse">Loading celebrities...</p>
              </motion.div>
            ) : currentImage ? (
              <motion.div 
                key={currentImage.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 1.1 }}
                className="max-w-4xl w-full grid grid-cols-1 md:grid-cols-2 gap-8 items-center"
              >
                {/* Image Container */}
                <div className="relative aspect-[3/4] rounded-3xl overflow-hidden shadow-2xl shadow-emerald-500/10 border border-neutral-800 group">
                  <img 
                    src={currentImage.url} 
                    alt={currentImage.name}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                  <div className="absolute bottom-6 left-6 right-6">
                    <p className="text-white font-bold text-2xl drop-shadow-lg">{currentImage.name}</p>
                  </div>
                </div>

                {/* Rating Controls */}
                <div className="space-y-8 text-center md:text-left">
                  <div className="space-y-2">
                    <h2 className="text-4xl font-bold tracking-tight">Rate this Photo</h2>
                    <p className="text-neutral-400">How would you rate this celebrity's appearance?</p>
                  </div>

                  <div className="flex justify-center md:justify-start gap-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <motion.button
                        key={star}
                        whileHover={{ scale: 1.2 }}
                        whileTap={{ scale: 0.9 }}
                        onClick={() => handleRate(star)}
                        className={`p-3 rounded-2xl transition-colors ${
                          currentRating && star <= currentRating 
                            ? "bg-emerald-500 text-black" 
                            : "bg-neutral-900 text-neutral-500 hover:bg-neutral-800"
                        }`}
                      >
                        <Star fill={currentRating && star <= currentRating ? "currentColor" : "none"} size={32} />
                      </motion.button>
                    ))}
                  </div>

                  <div className="pt-8">
                    <motion.button
                      disabled={currentRating === null}
                      onClick={handleNext}
                      className={`w-full py-4 rounded-2xl font-bold text-lg flex items-center justify-center gap-2 transition-all ${
                        currentRating !== null 
                          ? "bg-white text-black hover:bg-emerald-400" 
                          : "bg-neutral-800 text-neutral-600 cursor-not-allowed"
                      }`}
                    >
                      {currentIndex === images.length - 1 ? "Finish Rating" : "Next Celebrity"}
                      <ChevronRight size={20} />
                    </motion.button>
                  </div>

                  <div className="flex items-center gap-4 text-neutral-500 text-sm">
                    <div className="flex -space-x-2">
                      {[1,2,3].map(i => (
                        <div key={i} className="w-6 h-6 rounded-full border-2 border-neutral-950 bg-neutral-800" />
                      ))}
                    </div>
                    <p>Join 1,240+ others rating today</p>
                  </div>
                </div>
              </motion.div>
            ) : null}
          </AnimatePresence>
        </main>
      </div>
    );
  }

  if (view === "completion") {
    return (
      <div className="min-h-screen bg-neutral-950 text-white flex flex-col items-center justify-center p-6 font-sans">
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="max-w-xl w-full text-center space-y-8"
        >
          <div className="flex justify-center">
            <motion.div 
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", damping: 12 }}
              className="w-24 h-24 bg-emerald-500 rounded-full flex items-center justify-center text-black"
            >
              <CheckCircle size={48} />
            </motion.div>
          </div>

          <div className="space-y-4">
            <h1 className="text-5xl font-bold tracking-tight">Mission Complete!</h1>
            <p className="text-neutral-400 text-lg">Thank you for completing all 100 ratings. Your feedback helps us build the ultimate celebrity ranking.</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-neutral-900 p-6 rounded-3xl border border-neutral-800">
              <ImageIcon className="text-emerald-400 mb-2 mx-auto" size={24} />
              <p className="text-3xl font-bold">{images.length}</p>
              <p className="text-xs text-neutral-500 uppercase font-bold tracking-wider">Photos Rated</p>
            </div>
            <div className="bg-neutral-900 p-6 rounded-3xl border border-neutral-800">
              <Star className="text-emerald-400 mb-2 mx-auto" size={24} />
              <p className="text-3xl font-bold">
                {stats.filter(r => r.userId === userId).length > 0 
                  ? (stats.filter(r => r.userId === userId).reduce((acc: number, r: any) => acc + (r.rating || 0), 0) / stats.filter(r => r.userId === userId).length).toFixed(1)
                  : "0.0"}
              </p>
              <p className="text-xs text-neutral-500 uppercase font-bold tracking-wider">My Avg Rating</p>
            </div>
            <div className="bg-neutral-900 p-6 rounded-3xl border border-neutral-800">
              <BarChart3 className="text-emerald-400 mb-2 mx-auto" size={24} />
              <p className="text-3xl font-bold">
                {stats.length > 0 
                  ? (stats.reduce((acc: number, r: any) => acc + (r.rating || 0), 0) / stats.length).toFixed(1)
                  : "0.0"}
              </p>
              <p className="text-xs text-neutral-500 uppercase font-bold tracking-wider">Global Avg</p>
            </div>
          </div>

          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => window.location.reload()}
            className="w-full bg-neutral-800 hover:bg-neutral-700 text-white py-4 rounded-2xl font-bold transition-colors"
          >
            Start Over
          </motion.button>
        </motion.div>
      </div>
    );
  }

  return null;
}

